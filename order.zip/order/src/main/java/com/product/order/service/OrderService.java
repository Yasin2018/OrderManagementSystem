package com.product.order.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.annotation.Resource;
import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.order.dao.OrderRepository;
import com.product.order.model.Order;
import com.product.orderitem.model.OrderItem;



@Service
public class OrderService {
	

	@Autowired
	OrderRepository orderRepository;
	public List<Order> getOrders() {
        
		if( orderRepository.findAll().isEmpty()) {
			throw new EntityNotFoundException("Order Not Found");
			
		}else {
			return orderRepository.findAll();
		}

	}

	public Order getOrder(int orderId) {

		if(orderRepository.findById(orderId).isPresent()){
		return orderRepository.findById(orderId).get();
		}else{
			throw new EntityNotFoundException("Order Id " + orderId + " not found");
		}

	}

	public void createOrder(Order order) {
		
		orderRepository.save(order);

	}

	public void updateOrder(Order order) {
		
		orderRepository.save(order);
	}

	public void deleteOrder(int orderId) {

		
		orderRepository.deleteById(orderId);

	}
	
}
