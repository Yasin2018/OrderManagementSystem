package com.product.order.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.annotation.Resource;
import javax.persistence.EntityNotFoundException;
import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.product.order.model.Order;
import com.product.orderitem.model.OrderItem;





@RestController
@RequestMapping("/order")
public class OrderController {

	
	
	@Autowired
	private OrderService orderService;
	
	@Autowired
	private Validator validator;
	
	@Autowired
	OrderItemProxy orderItemProxy;
	
	@RequestMapping("/getorders")
	public List<Order> getOrders() {
		List<Order> orderList=orderService.getOrders();
		List<OrderItem> orderItems;
		
		for(Order order : orderList){
			try {
				orderItems=orderItemProxy.getItemsByOrderId(order.getOrderId());
			}catch(Exception e) {
				throw new EntityNotFoundException("No Item Found for Order Id in OrderController:"+order.getOrderId());
			}
			
			order.setOrderItems(orderItems);
			
		}
		
		
		return orderList;	
				
	}
	
	@RequestMapping("/getorder/{orderId}")
	public Order getOrder(@PathVariable int orderId) {
		List<OrderItem> orderItems=null;
        Order order=orderService.getOrder(orderId); 
		try {			
			orderItems=orderItemProxy.getItemsByOrderId(order.getOrderId());
			}catch(Exception e) {
				throw new EntityNotFoundException("No Item Found for Order Id :"+orderId);
			}
			
			order.setOrderItems(orderItems);
		return order;
				
	}
	
	
	@RequestMapping(method=RequestMethod.POST,value="/createorder/")
	public ResponseEntity<String> addOrder(@RequestBody Order order) {
		Set<ConstraintViolation<Order>> violations =validator.validate(order);
		StringBuilder sb=new StringBuilder();
		if(violations.size()>0) {
			for (ConstraintViolation<Order> violation : violations) {
				sb.append((violation.getMessage()));
				
			}
			throw new EntityNotFoundException("Input Validation Failed :\n"+sb.toString());
		}
		
		orderService.createOrder(order);
		
		return ResponseEntity.ok("Order Added successfully");
				
	}
	
	
	@RequestMapping(method=RequestMethod.PUT,value="/updateorder/")
	public ResponseEntity<String> updateOrder(@RequestBody Order order) {
		Set<ConstraintViolation<Order>> violations =validator.validate(order);
		StringBuilder sb=new StringBuilder();
		if(violations.size()>0) {
			for (ConstraintViolation<Order> violation : violations) {
				sb.append((violation.getMessage())); 
				
			}
			throw new EntityNotFoundException("Input Validation Failed :"+sb.toString());
		}
		orderService.updateOrder(order);
		
		return ResponseEntity.ok("Order Updated successfully");
				
	}
	
	
	@RequestMapping(method=RequestMethod.DELETE,value="/deleteorder/{orderId}")
	public void deleteOrder(@PathVariable int orderId) {
		
		orderService.deleteOrder(orderId);
				
	}
		
	
}
