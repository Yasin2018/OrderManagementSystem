package com.product.orderitem.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.product.orderitem.model.OrderItem;

@Entity
@Table(name="ORDER_ITEMS")
public class OrderItem implements Serializable {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@JsonProperty(access = Access.WRITE_ONLY)
	private int itemId;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private int orderId;
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	
	
	@NotBlank(message = "Product Code is mandatory")
	private String productCode;
	@NotBlank(message = "Product Name is mandatory")
	private String productName;
	@Min(1)
	private  int quantity;
	
	
	
		
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	
	
	
	
	public OrderItem() {
		
	}
	public OrderItem(int orderId,String productCode, String productName, int quantity) {
		super();
		this.orderId=orderId;		
		this.productCode = productCode;
		this.productName = productName;
		this.quantity = quantity;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
