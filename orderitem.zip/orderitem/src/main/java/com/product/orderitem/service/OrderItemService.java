package com.product.orderitem.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.orderitem.dao.OrderItemRepository;
import com.product.orderitem.model.OrderItem;



@Service
public class OrderItemService {


	@Autowired
	OrderItemRepository orderItemRepository;
	public List<OrderItem> getItems() {
		if( orderItemRepository.findAll().isEmpty()) {
			throw new EntityNotFoundException("Items Not Found");
			
		}else {
			return orderItemRepository.findAll();
		}

	}

	public List<OrderItem> getItemsByOrderId(int orderId) {

		if(orderItemRepository.findByOrderId(orderId).isEmpty()){
			throw new EntityNotFoundException("Item not found for Order Id  " + orderId  );
		}else{
			return orderItemRepository.findByOrderId(orderId);
			
		}


	}
	
	
	public OrderItem getItemsById(int itemId) {

		if(orderItemRepository.findById(itemId).isPresent()){
			return orderItemRepository.findById(itemId).get();
			
		}else{
			throw new EntityNotFoundException("Item not found for Order Id  " + itemId  );
			
		}


	}


	public void addItem(OrderItem orderItem) {

		orderItemRepository.save(orderItem);

	}

	public void updateItem(OrderItem orderItem) {

		orderItemRepository.save(orderItem);
	}

	public void deleteItem(int orderItemId) {


		orderItemRepository.deleteById(orderItemId);

	}

}
