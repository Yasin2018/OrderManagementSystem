package com.product.order.model;

import java.util.Date;
import java.util.List;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

import com.product.orderitem.model.OrderItem;

@Entity
@Table(name="order_details")
public class Order {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
   	private int orderId;
    @NotBlank(message = "Customer Name is mandatory")
	private String customerName;
    @NotNull(message = "Order Date is mandatory")
	private Date orderDate;
    @NotBlank(message = "Shipping Address is mandatory")
	private String shippingAddress;
    
    @NotNull(message = "Total cannot be null")
    @Min(1)
	private double total;
	@Transient
	private List<OrderItem> orderItems;
	
	
	public List<OrderItem> getOrderItems() {
		return orderItems;
	}
	public void setOrderItems(List<OrderItem> orderItems) {
		this.orderItems = orderItems;
	}
	public Order() {
		
	}
	public Order(int orderId,String customerName,Date orderDate,String shippingAddress,double total ) {
		this.orderId=orderId;
		this.customerName=customerName;
		this.orderDate=orderDate;
		this.shippingAddress=shippingAddress;
		this.total=total;
	}
	
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public String getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	
	
}
