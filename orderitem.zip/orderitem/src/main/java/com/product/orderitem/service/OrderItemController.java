package com.product.orderitem.service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.persistence.EntityNotFoundException;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.product.orderitem.model.OrderItem;



@RestController
@RequestMapping("/orderitem")
public class OrderItemController {

	
	@Autowired
	private OrderItemService orderItemService;
	
	@Autowired
	private Validator validator;
	
	@RequestMapping("/getitems")
	public List<OrderItem> getItems() {
		
		return orderItemService.getItems();
				
	}
	
	@RequestMapping("/getitemsbyorderid/{orderId}")
	public List<OrderItem> getItemsByOrderId(@PathVariable int orderId) {
		
		 return orderItemService.getItemsByOrderId(orderId);
		
				
	}
	
	
	@RequestMapping("/getitembyid/{itemId}")
	public OrderItem getItemsById(@PathVariable int itemId) {
		
		 return orderItemService.getItemsById(itemId);
		
				
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/additem")
	public ResponseEntity<String> addItem(@RequestBody OrderItem orderItem) {
		
		Set<ConstraintViolation<OrderItem>> violations =validator.validate(orderItem);
		StringBuilder sb=new StringBuilder();
		if(violations.size()>0) {
			for (ConstraintViolation<OrderItem> violation : violations) {
				sb.append((violation.getMessage())); 
				
				
			}
			throw new EntityNotFoundException("Input Validation Failed :"+sb.toString());
		}
		
		orderItemService.addItem(orderItem);
		return ResponseEntity.ok("Order Item Added successfully");
				
	}
	
	
	@RequestMapping(method=RequestMethod.PUT,value="/updateitem")
	public ResponseEntity<String> updateItem(@RequestBody OrderItem orderItem) {
		
		Set<ConstraintViolation<OrderItem>> violations =validator.validate(orderItem);
		StringBuilder sb=new StringBuilder();
		if(violations.size()>0) {
			for (ConstraintViolation<OrderItem> violation : violations) {
				sb.append((violation.getMessage())); 
				
			}
			throw new EntityNotFoundException("Input Validation Failed :"+sb.toString());
		}
		return ResponseEntity.ok("Order Item Updated successfully");
				
	}
	
	
	@RequestMapping(method=RequestMethod.DELETE,value="/deleteitem/{itemId}")
	public void deleteItem(@PathVariable int itemId) {
		
		orderItemService.deleteItem(itemId);
				
	}
		
	
}
