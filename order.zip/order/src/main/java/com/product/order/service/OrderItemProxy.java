package com.product.order.service;

import java.util.Collection;
import java.util.List;
import java.util.Optional;



import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.product.orderitem.model.OrderItem;
@Component
@FeignClient(name="OrderItem-Service")
public interface OrderItemProxy {
	 @RequestMapping(value = "/orderitem/getitemsbyorderid/{orderId}", method = RequestMethod.GET)
	 List<OrderItem> getItemsByOrderId(@PathVariable int orderId);
}

