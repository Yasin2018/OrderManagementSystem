package com.product.orderdiscoveryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderDiscoveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
